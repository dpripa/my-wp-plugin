<?php

namespace My_Core\Customize;

defined( 'ABSPATH' ) || exit;

class Settings_Code_Fields extends Base {

	protected static $section = 'my_code_fields';

	protected static $defaults = array(
		'head' => '',
		'body' => '',
	);

	public static function register( \WP_Customize_Manager $wp_customize ) {
		$wp_customize->add_section(
			self::$section,
			array(
				'title'       => esc_html__( 'Code Fields', 'my_plugin' ),
				'description' => esc_html__( 'text', 'my_plugin' ),
				'panel'       => 'my_settings',
			)
		);

		$name = 'head';
		$wp_customize->add_setting(
			self::apply_prefix( $name ),
			array(
				'default'   => self::$defaults[ $name ],
				'transport' => false,
			)
		);
		$wp_customize->add_control(
			new \WP_Customize_Code_Editor_Control(
				$wp_customize,
				self::apply_prefix( $name ),
				array(
					'label'           => __( 'Code entry area before the closing </head> tag', 'my_plugin' ),
					'description'     => esc_html__( 'Only accepts JavaScript code wrapped with <script/> tags and HTML markup that is valid inside the </head> tag.', 'my_plugin' ),
					'editor_settings' => array(
						'codemirror' => array(
							'mode' => 'htmlmixed',
						),
					),
					'section'         => self::$section,
				)
			)
		);

		$name = 'body';
		$wp_customize->add_setting(
			self::apply_prefix( $name ),
			array(
				'default'   => self::$defaults[ $name ],
				'transport' => false,
			)
		);
		$wp_customize->add_control(
			new \WP_Customize_Code_Editor_Control(
				$wp_customize,
				self::apply_prefix( $name ),
				array(
					'label'           => __( 'Code entry area before the closing </body> tag', 'my_plugin' ),
					'description'     => esc_html__( 'Only accepts JavaScript code, wrapped with <script/> tags and valid HTML markup inside the </body> tag.', 'my_plugin' ),
					'editor_settings' => array(
						'codemirror' => array(
							'mode' => 'htmlmixed',
						),
					),
					'section'         => self::$section,
				)
			)
		);
	}
}
