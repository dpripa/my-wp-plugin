<?php

namespace My_Core\Customize;

defined( 'ABSPATH' ) || exit;

abstract class Base {

	protected static $section  = '';
	protected static $defaults = array();

	protected static function apply_prefix( string $name ): string {
		return static::$section . '_' . $name;
	}

	public static function register( \WP_Customize_Manager $wp_customize ) {
	}

	public static function get_mod( string $name ) {
		$mod = get_theme_mod( static::apply_prefix( $name ) );

		return ( false !== $mod && '' !== $mod ) ? $mod : static::$defaults[ $name ];
	}
}
