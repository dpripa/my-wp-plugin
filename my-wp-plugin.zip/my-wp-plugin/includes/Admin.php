<?php

namespace My_Core;

defined( 'ABSPATH' ) || exit;

class Admin {

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ), 100 );
	}

	public function enqueue_assets() {
		Utils::enqueue_style( 'my_admin', 'admin' );
		Utils::enqueue_script( 'my_admin', 'admin' );
	}
}
