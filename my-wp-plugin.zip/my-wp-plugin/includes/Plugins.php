<?php

namespace My_Core;

defined( 'ABSPATH' ) || exit;

class Plugins {

	public function __construct() {
		new Plugins\Polylang();
		new Plugins\WC();
	}
}
