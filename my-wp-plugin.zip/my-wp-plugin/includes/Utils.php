<?php

namespace My_Core;

defined( 'ABSPATH' ) || exit;

class Utils {

	public static function enqueue_style( string $handle, string $slug, array $deps = array() ) {
		wp_enqueue_style( $handle, MY_CORE_URL . 'assets/styles/' . $slug . '.min.css', $deps, filemtime( MY_CORE_PATH . 'assets/styles/' . $slug . '.min.css' ) );
	}

	public static function enqueue_script( string $handle, string $slug, array $deps = array(), bool $in_footer = true ) {
		wp_enqueue_script( $handle, MY_CORE_URL . 'assets/scripts/' . $slug . '.min.js', $deps, filemtime( MY_CORE_PATH . 'assets/scripts/' . $slug . '.min.js' ), $in_footer );
	}
}
