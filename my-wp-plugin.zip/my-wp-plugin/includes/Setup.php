<?php

namespace My_Core;

defined( 'ABSPATH' ) || exit;

final class Setup {

	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'plugin_loaded' ) );
		add_action( 'wp_default_scripts', array( $this, 'remove_jquery_migrate' ) );
		$this->clean_head();
	}

	public function plugin_loaded() {
		load_plugin_textdomain( 'my_plugin', false, MY_CORE_PATH . 'languages' );

		new Customize();
		new Admin();
		new Acf();
		new Plugins();
	}

	public function remove_jquery_migrate( \WP_Scripts $scripts ) {
		if ( Customize\Settings_General::get_mod( 'remove_jquery_migrate' ) && ! is_admin() && isset( $scripts->registered['jquery'] ) ) {
			$script = $scripts->registered['jquery'];

			if ( $script->deps ) {
				$script->deps = array_diff( $script->deps, array( 'jquery-migrate' ) );
			}
		}
	}

	private function clean_head() {
		if ( Customize\Settings_General::get_mod( 'clean_head' ) ) {
			remove_action( 'wp_head', 'rsd_link' );
			remove_action( 'wp_head', 'wlwmanifest_link' );
			remove_action( 'wp_head', 'start_post_rel_link' );
			remove_action( 'wp_head', 'index_rel_link' );
			remove_action( 'wp_head', 'adjacent_posts_rel_link' );
			remove_action( 'wp_head', 'wp_shortlink_wp_head' );
			remove_action( 'wp_head', 'rest_output_link_wp_head' );
			remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
			remove_action( 'wp_head', 'wp_generator' );
			remove_action( 'wp_head', 'print_emoji_detection_script' );
			remove_action( 'template_redirect', 'rest_output_link_header' );
			remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
			remove_action( 'wp_print_styles', 'print_emoji_styles' );
			remove_action( 'admin_print_styles', 'print_emoji_styles' );
		}
	}
}
