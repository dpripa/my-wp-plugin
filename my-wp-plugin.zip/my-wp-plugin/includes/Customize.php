<?php

namespace My_Core;

defined( 'ABSPATH' ) || exit;

class Customize {

	public function __construct() {
		add_action( 'customize_controls_enqueue_scripts', array( $this, 'controls_enqueue_assets' ) );
		add_action( 'customize_register', array( $this, 'register' ) );
	}

	public function controls_enqueue_assets() {
		Utils::enqueue_style( 'my_customize_controls', 'customize-controls', array( 'wp-color-picker' ) );
		Utils::enqueue_script( 'my_customize_controls', 'customize-controls', array( 'jquery', 'customize-controls', 'wp-color-picker' ) );
	}

	public function register( \WP_Customize_Manager $wp_customize ) {
		$wp_customize->add_panel(
			'my_settings',
			array(
				'title'       => esc_html__( 'My Settings', 'my_plugin' ),
				'description' => esc_html__( 'text', 'my_plugin' ),
				'priority'    => 121,
			)
		);
		Customize\Settings_General::register( $wp_customize );
		Customize\Settings_Code_Fields::register( $wp_customize );
	}
}
