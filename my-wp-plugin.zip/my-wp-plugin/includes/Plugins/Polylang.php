<?php

namespace My_Core\Plugins;

defined( 'ABSPATH' ) || exit;

class Polylang {

	public function __construct() {
		if ( function_exists( 'pll_the_languages' ) ) {
			add_filter( 'my_theme_home_url', array( $this, 'home_url' ) );
		}
	}

	public function home_url() {
		return pll_home_url();
	}
}
