<?php

namespace My_Core\Acf;

defined( 'ABSPATH' ) || exit;

class Header_Menu extends Base {

	public static $field_group = 'my_header_menu';

	public static function register() {
		acf_add_local_field_group(
			array(
				'key'                   => self::$field_group,
				'title'                 => __( 'Header Menu', 'my_plugin' ),
				'fields'                => array(
					array(
						'key'           => self::apply_prefix( 'type' ),
						'label'         => __( 'Type', 'my_plugin' ),
						'name'          => 'my_type',
						'type'          => 'select',
						'choices'       => array(
							'default' => __( 'Default link', 'my_plugin' ),
							'tel'     => __( 'Phone number', 'my_plugin' ),
						),
						'default_value' => 'default',
						'allow_null'    => 0,
						'multiple'      => 0,
						'ui'            => 0,
						'return_format' => 'value',
						'ajax'          => 0,
						'placeholder'   => '',
					),
				),
				'location'              => array(
					array(
						array(
							'param'    => 'nav_menu_item',
							'operator' => '==',
							'value'    => 'location/my_header_menu',
						),
					),
				),
				'position'              => 'normal',
				'style'                 => 'default',
				'label_placement'       => 'top',
				'instruction_placement' => 'label',
				'active'                => true,
			)
		);
	}
}
