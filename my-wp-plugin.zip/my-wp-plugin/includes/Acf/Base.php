<?php

namespace My_Core\Acf;

defined( 'ABSPATH' ) || exit;

abstract class Base {

	protected static $field_group = '';

	protected static function apply_prefix( string $name ): string {
		return static::$field_group . '_' . $name;
	}

	public static function register() {
	}
}
