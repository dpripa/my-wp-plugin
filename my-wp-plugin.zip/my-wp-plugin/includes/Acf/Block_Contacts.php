<?php

namespace My_Core\Acf;

defined( 'ABSPATH' ) || exit;

class Block_Contacts extends Base {

	public static function register() {
		acf_add_local_field_group( array() );
	}
}
