# My WordPress Theme Core Boilerplate
This is the core plugin for my theme boilerplate: <http://github.com/dpripa/my-wp-theme>. For more information go to the theme [README.md](http://github.com/dpripa/my-wp-theme/blob/main/README.md) file.
